*PADS-LIBRARY-PART-TYPES-V9*

EC16E20-24P24C-SW EC16E2024P24CSW I SWI 9 1 0 0 0
TIMESTAMP 2026.08.06.08.08.36
"Manufacturer_Name" SRPASSIVES
"Manufacturer_Part_Number" EC16E20-24P24C-SW
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Specification ; Resolution. 24imp/revol. ; Number of positions. 24 ; Output signal. two phase A and B ; Mechanical durability. 50000 cycles ; Operating voltage. 5V ..
"Datasheet Link" https://www.tme.eu/Document/56f07056c56a74881a9c3bc32fab901d/EC16E20-24P24C-SW.pdf
"Geometry.Height" 28mm
GATE 1 7 0
EC16E20-24P24C-SW
A1 0 U CCW
B1 0 U WIPER
C1 0 U CW
S1 0 U S1
S2 0 U S2
MH1 0 U MH1
MH2 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
18423232/2123509/2.50/7/3/Switch
