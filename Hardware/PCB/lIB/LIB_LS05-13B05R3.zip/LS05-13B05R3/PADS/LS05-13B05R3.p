*PADS-LIBRARY-PART-TYPES-V9*

LS05-13B05R3 LS0513B05R3 I ANA 9 1 0 0 0
TIMESTAMP 2026.09.23.15.37.59
"Manufacturer_Name" Morunsun
"Manufacturer_Part_Number" LS05-13B05R3
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" AC DC CONVERTER,5W,5VDC
"Datasheet Link" https://www.mornsun-power.com/html/pdf/LS05-13B05R3.html
"Geometry.Height" 15.73mm
GATE 1 6 0
LS05-13B05R3
1 0 U AC_(L)
2 0 U AC_(N)
3 0 U +V_(CAP)
4 0 U -V_(CAP)
5 0 U -VO
6 0 U +VO

*END*
*REMARK* SamacSys ECAD Model
13639200/2123509/2.50/6/4/Power Supply
